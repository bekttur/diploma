import axios from "axios";

export const getProducts = async () => {
  const response = await fetch(
    "https://62ee2508a785760e677490fc.mockapi.io/bekttur/apple"
  );
  return await response.json();
};