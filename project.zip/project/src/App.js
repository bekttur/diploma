import logo from './logo.svg';
import './App.css';
import { Header } from './components/Header/Header';
import { BrowserRouter } from 'react-router-dom';
import { AuthContext } from './components/UI/context';
import { AppRouter } from './components/AppRouter/AppRouter';
import { useEffect, useState } from 'react';


function App() {

  const [isAuth, setIsAuth] = useState(false)

  useEffect(() => {
    if (localStorage.getItem('auth')) {
      setIsAuth(true)
    }
  }, [])


  return (

    <AuthContext.Provider value={{
      isAuth,
      setIsAuth
    }}>
      <BrowserRouter>
        <Header />
        <AppRouter />
      </BrowserRouter>
    </AuthContext.Provider>
  );
}

export default App;
