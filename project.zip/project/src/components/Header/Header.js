import "./Header.css"
import React, { useContext, useState } from 'react'
import { Outlet, Link } from "react-router-dom";
import { AuthContext } from "../UI/context";
import { Button } from "../UI/button/Button";
import { Hamburger } from "./Hamburger/Hamburger";

export const Header = () => {
    const { isAuth, setIsAuth } = useContext(AuthContext)

    const logout = () => {
        setIsAuth(false)
        localStorage.removeItem('auth')
    }

    const [hamburgerOpen, setHamburgerOpen] = useState(false)

    const toggleHamburger = () => {
        setHamburgerOpen(!hamburgerOpen)
    }

    return (
        <div>
            <div className="navbar">
                <ul className="item_block">
                    <li>
                        <Link className="navbar_link" to={"/"}>
                            <img className="apple-logo-img" src="../menu/apple_image.svg" />
                        </Link>
                    </li>
                    <li>
                        <Link className="navbar_link" to={"/mac"}>
                            <img src="../menu/mac_image.svg" />
                        </Link>
                    </li>
                    <li>
                        <Link className="navbar_link" to={"/ipad"}>
                            <img src="../menu/ipad_image.svg" />
                        </Link>
                    </li>
                    <li>
                        <Link className="navbar_link" to={"/iphone"}>
                            <img src="../menu/iphone_image.svg" />
                        </Link>
                    </li>
                    <li>
                        <Link className="navbar_link" to={"/watch"}>
                            <img src="../menu/watch_image.svg" />
                        </Link>
                    </li>
                    <li>
                        <Link className="navbar_link" to={"/airpods"}>
                            <img src="../menu/airpods_image.svg" />
                        </Link>
                    </li>
                    <li>
                        <Link className="navbar_link" to={"/search"}>
                            {/* <img className="search-image" src="../menu/search_image.svg" /> */}
                            <img style={{width: 23}} src="../menu/search-white.png" />
                        </Link>
                    </li>
                    <li>
                        <Link className="navbar_link" to={"/basket/products"}>
                            <img src="../menu/globalnav.svg" />
                        </Link>
                    </li>
                    <li>
                        <img onClick={logout} style={{ width: 15 }} src="../menu/icon_log_out.png" />
                    </li>
                </ul>

                <div className="hamburger2" onClick={toggleHamburger}>
                    <Hamburger isOpen={hamburgerOpen} />
                </div>
            </div>
            <style jsx>{`
                @media (max-width: 768px){
                    .hamburger2{
                        display: flex;
                        padding-top: 10px;
                        margin-left: 10px;
                        z-index: 6;
                    }

                    .item_block{
                        display: ${hamburgerOpen ? 'inline' : 'none'};
                        background-color: rgba(0,0,0,0.88);
                        height: 100vh;
                        width: 50vw;
                        margin-top: 833px;
                        position: fixed;
                    }
                }
            `}</style>
            <br />
            <Outlet />
        </div>
    )
}