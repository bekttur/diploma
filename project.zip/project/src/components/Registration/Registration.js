
import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import "./Registration.css"

export const Registration = ({ userArray }) => {

    const [nameValue, setNameValue] = useState("")
    const [phoneValue, setPhoneValue] = useState("")
    const [emailValue, setEmailValue] = useState("")
    const [passwordValue, setPasswordValue] = useState("")
    const [passwordSecurityValue, setPasswordSecurityValue] = useState("")

    const [emailDirty, setEmailDirty] = useState(false)
    const [passwordDirty, setPasswordDirty] = useState(false)
    const [passwordSecurityDirty, setPasswordSecurityDirty] = useState(false)
    const [nameDirty, setNameDirty] = useState(false)
    const [emailError, setEmailError] = useState('Логин не может быть пустым!')
    const [passwordError, setPasswordError] = useState("Пароль не может быть пустым!")
    const [passwordSecurityError, setPasswordSecurityError] = useState("Пароль не может быть пустым!")
    const [nameError, setNameError] = useState("Имя не может быть пустым!")
    const [formValid, setFormValid] = useState(false)

    const nameHandler = (e) => {
        setNameValue(e.target.value)
        if (e.target.value.length < 2) {
            setNameError('Имя должен быть длинее 2!')
            if (!e.target.value) {
                setNameError('Имя не может быть пустым!')
            }
        } else {
            setNameError('')
        }
    }

    const phoneHandler = (e) => {
        setPhoneValue(e.target.value)
    }

    const emailHandler = (e) => {
        setEmailValue(e.target.value)
        const re = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
        if (!re.test(String(e.target.value).toLowerCase())) {
            setEmailError('Некорректный логин!')
        } else {
            setEmailError('')
        }

        userArray.map(item => {
            if (e.target.value == item.email) {
                setEmailError("Вы уже зарегистрированы!");
                userArray.splice(userArray.length - 1, 1)
            } else {
                setEmailError("");
            }
            console.log(userArray);
        })
    }

    const passwordHandler = (e) => {
        setPasswordValue(e.target.value)
        if (e.target.value.length < 3 || e.target.value.length > 12) {
            setPasswordError('Пароль должен быть длинее 3 и  меньше 12!')
            if (!e.target.value) {
                setPasswordError('Пароль не может быть пустым!')
            }
        } else {
            setPasswordError('')
        }
    }

    const passwordSecurityHandler = (e) => {
        setPasswordSecurityValue(e.target.value)
        if (e.target.value !== passwordValue) {
            setPasswordSecurityError("Пароль не совпадает!")
            if (!e.target.value) {
                setPasswordSecurityError('Пароль не может быть пустым!')
            }
        } else {
            setPasswordSecurityError('')
        }
    }

    const blurHandler = (e) => {
        switch (e.target.name) {
            case "email":
                setEmailDirty(true);
                break;
            case 'password':
                setPasswordDirty(true);
                break;
            case 'name':
                setNameDirty(true);
                break;
            case 'password_security':
                setPasswordSecurityDirty(true)
                break;
        }
    }

    useEffect(() => {
        if (emailError || passwordError || nameError || passwordSecurityError) {
            setFormValid(false)
        } else {
            setFormValid(true)
        }
    }, [emailError, passwordError, nameError, passwordSecurityError])


    const alertNotification = () => {
        alert('Вы успешно зарегистрировались')
    }




    const Register = (e) => {
        e.preventDefault()
        if (passwordValue == passwordSecurityValue) {

            const userObject = {
                name: nameValue,
                phone: phoneValue,
                email: emailValue,
                password: passwordValue,
                passwordSecurity: passwordSecurityValue,
                array: []
            }
            userArray.push(userObject)
        }

        localStorage.setItem('userArray', JSON.stringify(userArray))
        console.log(userArray);
    }




    return (
        <div className="register_block">
            <div className="register_card">
                <h1>Страница для Регистрации</h1>
                <form onSubmit={Register} method="get" className="register_form">
                    {(nameDirty && nameError) && <div className="error_text">{nameError}</div>}
                    <input name="name" onChange={(e) => nameHandler(e)} className="register_input" onBlur={e => blurHandler(e)} type="text" placeholder="Введите имя..." />
                    <input name="phone" onChange={(e) => phoneHandler(e)} className="register_input" type="tel" placeholder="Введите телефон номер..." />
                    {(emailDirty && emailError) && <div className="error_text">{emailError}</div>}
                    <input name="email" value={emailValue} onChange={(e) => emailHandler(e)} onBlur={e => blurHandler(e)} className="register_input" type="text" placeholder="Введите логин..." />
                    {(passwordDirty && passwordError) && <div className="error_text">{passwordError}</div>}
                    <input name="password" value={passwordValue} onChange={(e) => passwordHandler(e)} onBlur={e => blurHandler(e)} className="register_input" type="password" placeholder="Введите пароль..." />
                    {(passwordSecurityDirty && passwordSecurityError) && <div className="error_text">{passwordSecurityError}</div>}
                    <input name="password_security" onChange={(e) => passwordSecurityHandler(e)} onBlur={e => blurHandler(e)} className="register_input" type="password" placeholder="Подтверждение пароля..." />
                    <button type="submit" disabled={!formValid} onClick={alertNotification} className="register_button">Регистрация</button>
                </form>
                <p>Есть аккаунт? <Link to={"login"}>Вход</Link> </p>
            </div>
        </div>
    )
}