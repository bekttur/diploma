import React from "react"

export const Appearance = ({children}) => {
    return (
        <img src={children} />
    )
}