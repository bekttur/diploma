import React from "react"
import { Button } from "../../UI/button/Button"
import "./Card.css"
import { Price } from "./price/Price"

export const Card = ({ children, price }) => {
    return (
        <div className="mac_card">
            <div className="card_text" style={{ textAlign: "center" }}>
                <p style={{fontSize: 20, fontWeight: 600}}>{children}</p>
                {/* <Button>Купить</Button> */}
            </div>
        </div>
    )
}