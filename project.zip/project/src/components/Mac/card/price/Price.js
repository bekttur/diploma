import React from "react"
import "./Price.css"

export const Price = ({children}) => {
    return (
        <p style={{fontSize: 17, color: "#0071e3", fontWeight: 600}}>От {children} ₸</p>
    )
}