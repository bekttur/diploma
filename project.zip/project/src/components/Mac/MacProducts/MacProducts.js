import React, { useContext, useEffect, useState } from "react";
import { useParams } from "react-router";
import "./MacProducts.css"
import { apple } from "../../apple"
import { AuthContext } from "../../UI/context";
import { Link } from "react-router-dom";
import { Button } from "../../UI/button/Button";
import { getProducts } from "../../../API/productsAPI";


export const MacProducts = ({ userArray, loginArray }) => {
    let { id } = useParams();

    let productId = id - 1;

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    const [newPrice, setNewPrice] = useState(apple[0].mac[`${id - 1}`].price)


    const [isGrayDisplay, setIsGrayDisplay] = useState(true)
    const [isHoverMemory, setIsHoverMemory] = useState(true)
    const [isHoverStorage, setIsHoverStorage] = useState(true)

    const buyProduct = () => {
        if (productId + 1 == id) {
            const object = {
                id: appleApi[0].mac[productId].id,
                name: appleApi[0].mac[productId].name,
                price: newPrice,
                color: isGrayDisplay,
                image1: appleApi[0].mac[productId].macbook_color1,
                image2: appleApi[0].mac[productId].macbook_color2,
                memory: isHoverMemory,
                storage: isHoverStorage
            }

            userArray.map(item => {
                if (loginArray[0].login == item.email) {
                    item.array.push(object)
                }
            })

        }

        localStorage.setItem('userArray', JSON.stringify(userArray))
        localStorage.setItem('loginArray', JSON.stringify(loginArray))
        console.log(userArray);
    }



    const { valueLogin, setValueLogin } = useContext(AuthContext)



    const onChangeValue = (event) => {
        if (event.target.value == "gray") {
            setIsGrayDisplay(true)
            console.log(valueLogin)
        } else {
            setIsGrayDisplay(false)
        }
    }


    const onClickMemory = () => {
        if (isHoverMemory == true) {
            setIsHoverMemory(false)
            setNewPrice(newPrice + 25000)
        } else {
            setIsHoverMemory(true)
            setNewPrice(newPrice - 25000)
        }
    }

    const onClickStorage = () => {
        if (isHoverStorage == true) {
            setIsHoverStorage(false)
            setNewPrice(newPrice + 25000)
        } else {
            setIsHoverStorage(true)
            setNewPrice(newPrice - 25000)
        }
    }



    return (
        <>
            {appleApi.length !== 0
                ?
                appleApi[0].mac.map(item => {
                    if (item.id === +id) {
                        return (
                            <div>
                                <div className="macpage_block">
                                    <div
                                        className="mac_background"
                                        style={{
                                            backgroundPositionX: "left",
                                            backgroundPositionY: "50%",
                                            backgroundRepeat: "no-repeat",
                                            backgroundImage: `url(${item.backgroundImage})`
                                        }}>
                                    </div>
                                    <div className="macpage_descriptions" style={{ background: `${item.backgoundColor}`, color: `${item.fontColor}` }}>
                                        <div className="information_block">
                                            <h2 className="product_name">{item.name}</h2>
                                            <h1 className="product_mainText" style={{ margin: "-5px 0 15px 0" }}>{item.mainText}</h1>
                                            <h3 className="product_description">{item.description}</h3>
                                            <p style={{ color: "#767676", fontSize: 20, fontWeight: 600 }}>От {item.price} ₸</p>
                                        </div>
                                        <div className="product_info">
                                            <div className="macInfo_block">
                                                <div className="product_item">
                                                    <div className="item_info">
                                                        <h3>{item.information.display}</h3>
                                                        <p>Дисплей</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.chip_img} />
                                                        <p>{item.information.chip}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <h3>{item.information.CPU}</h3>
                                                        <p>Процессор</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <h3>{item.information.GPU}</h3>
                                                        <p>Графический процесор</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <h3>{item.information.memory}</h3>
                                                        <p>Максимальное хранилище</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.battery_img} />
                                                        <p>До {item.information.battery_time} часов работы</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.camera_img} />
                                                        <p>HD-камера FaceTime {item.information.camera}p</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <h3>{item.information.weight} фунт</h3>
                                                        <p>Вес</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.touchId_img} />
                                                        <p>{item.information.touchId}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="memory_block">
                                            <p style={{ fontSize: 45, fontWeight: 900 }}>До {item.information.memory}</p>
                                            <p style={{ fontSize: 20, fontWeight: 600 }}>Возьмите с собой фотографии, фильмы, музыку и документы и откройте их мгновенно.</p>
                                        </div>
                                        <div className="buy_product_block">
                                            <div className="product_appearance">
                                                <div className="mac_appearance_img">
                                                    <img className="for_mobile_productImg" src={item.macbook_color1} style={{ display: isGrayDisplay ? 'block' : 'none' }} />
                                                    <img className="for_mobile_productImg" src={item.macbook_color2} style={{ display: isGrayDisplay ? 'none' : 'block' }} />
                                                </div>
                                                <div className="for_price_block">
                                                    <h1>{newPrice} ₸</h1>
                                                </div>
                                            </div>
                                            <div className="product_dates">
                                                <div className="chip_block">
                                                    <img src={item.information.chip_img} />
                                                </div>
                                                <div className="product_color" onChange={onChangeValue}>
                                                    <h3>Цвет:</h3>
                                                    <label>
                                                        <img src={item.color1} />
                                                        <input style={{ opacity: 0 }} type="radio" name="color" value={item.input_value1} />
                                                    </label>
                                                    <label>
                                                        <img src={item.color2} />
                                                        <input style={{ opacity: 0 }} type="radio" name="color" value={item.input_value2} />
                                                    </label>
                                                </div>
                                                <div className="memory_date_block">
                                                    <h3>Память:</h3>
                                                    <p className="qwestion_for_date">Сколько память вам подходит?</p>
                                                    <label>
                                                        <div className="memory_card" onClick={onClickMemory} style={{ border: isHoverMemory ? "2px solid #0071e3" : "1px solid #86868b" }}>
                                                            <h3>8 ГБ единой памяти</h3>
                                                            <p style={{ opacity: isHoverMemory ? 0 : 1 }} >- 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="memory" />
                                                    </label>
                                                    <label>
                                                        <div className="memory_card" onClick={onClickMemory} style={{ border: isHoverMemory ? "1px solid #86868b" : "2px solid #0071e3" }}>
                                                            <h3>16 ГБ единой памяти</h3>
                                                            <p style={{ opacity: isHoverMemory ? 1 : 0 }} >+ 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="memory" />
                                                    </label>
                                                </div>
                                                <div className="storage_date_block">
                                                    <h3>Хранение:</h3>
                                                    <p className="qwestion_for_date">Сколько места для хранения подходит вам?</p>
                                                    <label>
                                                        <div className="storage_card" onClick={onClickStorage} style={{ border: isHoverStorage ? "2px solid #0071e3" : "1px solid #86868b" }}>
                                                            <h3>256 ГБ SSD-накопителя</h3>
                                                            <p style={{ opacity: isHoverStorage ? 0 : 1 }} >- 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="storage" />
                                                    </label>
                                                    <label>
                                                        <div className="storage_card" onClick={onClickStorage} style={{ border: isHoverStorage ? "1px solid #86868b" : "2px solid #0071e3" }}>
                                                            <h3>512 ГБ SSD-накопителя</h3>
                                                            <p style={{ opacity: isHoverStorage ? 1 : 0 }} >+ 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="storage" />
                                                    </label>
                                                </div>
                                                <Link to={'/basket/products'}>
                                                    <Button onClick={buyProduct}>Купить</Button>
                                                </Link>
                                            </div>
                                        </div>
                                        <div className="magicKey_block">
                                            <div className="keyboard_description">
                                                <h1 className="keyboard_mainText">Magic Keyboard</h1>
                                                <p className="keyboard_paragraf">Когда клавиатура печатает как сон и все еще делает намного больше, это волшебство. Благодаря предварительно запрограммированным ярлыкам полезные функции легко доступны. Получите помощь от Siri, переключите языки клавиатуры, ответьте идеальными эмодзи, найдите документы с помощью Spotlight - вы можете многое сделать одним касанием. А клавиши с подсветкой и датчиком внешней освещенности помогают печатать настройки при слабом освещении.</p>
                                            </div>
                                            <div>
                                                <img style={{ width: "50%" }} src={item.information.keyboard} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )
                    }
                })
                :
                null
            }
        </>
    )
}