import React, { useContext, useEffect, useState } from "react"
import "./Mac.css"
import { Button } from "../UI/button/Button"
import { Card } from "./card/Card"
import { Price } from "./card/price/Price"
import { Appearance } from "./card/images/appearance"
import { MacbookPro } from "../Main/MacbookPro/MacbookPro"
import { MacbookAir } from "../Main/MacbookAir/MacbookAir"
import { Benefits } from "../Benefits/Benefits"
import { Link } from "react-router-dom"
import { getProducts } from "../../API/productsAPI";


export const Mac = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    console.log(appleApi);

    
    return (
        <div>
            <MacbookAir />
            <br />
            <br />
            <br />
            <MacbookPro />
            <div className="mac_block">
                <div className="mac_container">
                    <div className="mac_description">
                        <h1 className="main_paragraf">Какой Mac правильно для тебя?</h1>
                    </div>
                    <div className="mac_items">
                        <div className="products">
                            {appleApi.length !== 0
                                ?
                                appleApi[0].mac.map(item => {
                                return (
                                    <Card>
                                        <Link to={"/mac/" + `${item.id}`}>
                                            <div style={{ marginBottom: 20 }}>
                                                <Appearance>{item.image}</Appearance>
                                            </div>
                                            {item.name}
                                            <Price>{item.price}</Price>
                                            <Button>Купить</Button>
                                        </Link>
                                    </Card>
                                )
                            })
                            :
                            null
                        }
                        </div>
                    </div>
                    <Benefits />
                </div>
            </div>
        </div>
    )
}