import React, { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { Price } from "../../Mac/card/price/Price"
import "./AirPodsPro.css"
import { getProducts } from "../../../API/productsAPI"



export const AirPodsPro = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    return (
        <div>
            <Link to={"/airpods/22"}>
                <div className="airpodspro_container">
                    <div className="airpodspro_img">
                        <img className="airpods_pro_left" src="../AirPods/AirPodsPro/airpods_pro_left.png" />
                        <img className="airpods_pro_right" src="../AirPods/AirPodsPro/airpods_pro_right.png" />
                    </div>
                    <div className="airpods_pro_text">
                        <h1 className="airpodsPro_paragraf">AirPods Pro</h1>
                        <p style={{ fontSize: 21, letterSpacing: ".011em", fontWeight: 600, marginTop: -55 }}>
                            {appleApi.length !== 0
                                ?
                                appleApi[0].airpods[2].price
                                :
                                null} ₸
                    </p>
                    </div>
                </div>
            </Link>
        </div>
    )
}