import React, { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { Price } from "../../Mac/card/price/Price"
import "./AirPodsMax.css"
import { getProducts } from "../../../API/productsAPI"


export const AirPodsMax = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    return (
        <div>
            <Link to={"/airpods/23"}>
                <div className="airpodsmax_block" style={{ backgroundColor: "white" }}>
                    <div className="airpodsmax_container">
                        <div className="airpodsmax_img">
                            <img className="airpods_max" src="../AirPods/AirPodsMax/airpods_max.png" />
                        </div>
                        <div className="airpods_max_text">
                            <p className="airpods_price">{appleApi.length !== 0
                                ?
                                appleApi[0].airpods[3].price
                                :
                                null} ₸</p>
                        </div>
                    </div>
                </div>
            </Link>
        </div>
    )
}