import React, { useEffect, useState } from "react"
import { AirPodsMax } from "./AirPodsMax/AirPodsMax";
import { AirPodsPro } from "./AirPodsPro/AirPodsPro";
import { Benefits } from "../Benefits/Benefits";
import "./AirPods.css"
import { Card } from "../Mac/card/Card";
import { Appearance } from "../Mac/card/images/appearance";
import { Price } from "../Mac/card/price/Price";
import { Button } from "../UI/button/Button";
import { Link } from "react-router-dom";
import { getProducts } from "../../API/productsAPI";


export const AirPods = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);


    return (
        <div>
            <AirPodsPro />
            <AirPodsMax />
            <div style={{ marginBottom: 80 }}>
                <Link to={"/airpods/20"}>
                    <div className="airpods_block">
                        <div className="airpods_container">
                            <div className="airpods_img">
                                <img className="airpods_left" src="../AirPods/airpods_left.png" />
                                <img className="airpods_right" src="../AirPods/airpods_right.png" />
                            </div>
                            <div className="airpods_text">
                                <h1 className="airpods_name">AirPods</h1>
                                <div className="airpods2_price">
                                    <p>2-е поколение</p>
                                    <p>{appleApi.length !== 0
                                        ?
                                        appleApi[0].airpods[0].price
                                        :
                                        null} ₸</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </Link>
            </div>

            <div className="airpods_items">
                <div className="airpods_description">
                    <h1 className="main_paragraf">Какие AirPods подходят именно вам?</h1>
                </div>
                <div className="products">
                    {appleApi.length !== 0
                        ?
                        appleApi[0].airpods.map(item => {
                            return (
                                <div className="for_mobile">
                                    <Card>
                                        <Link to={"/airpods/" + `${item.id}`}>
                                            <div style={{ marginBottom: 20 }}>
                                                <Appearance>{item.image}</Appearance>
                                            </div>
                                            {item.name}
                                            <Price>{item.price}</Price>
                                            <Button>Купить</Button>
                                        </Link>
                                    </Card>
                                </div>
                            )
                        })
                        :
                        null}
                </div>
                <Benefits />
            </div>
        </div>
    )
}