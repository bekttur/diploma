import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import { Benefits } from "../../Benefits/Benefits";
import "./AirProducts.css"
import { apple } from "../../apple"
import { Link } from "react-router-dom";
import { Button } from "../../UI/button/Button";
import { getProducts } from "../../../API/productsAPI";


export const AirProducts = ({ userArray, loginArray }) => {
    let { id } = useParams();

    let productId = id - 20;

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    const [newPrice, setNewPrice] = useState(apple[0].airpods[productId].price)

    const buyProduct = () => {
        if (productId + 20 == id) {
            const object = {
                id: appleApi[0].airpods[productId].id,
                name: appleApi[0].airpods[productId].name,
                price: newPrice,
                image1: appleApi[0].airpods[productId].airpods_color1,
                image2: appleApi[0].airpods[productId].airpods_color1,
            }

            userArray.map(item => {
                if (loginArray[0].login == item.email) {
                    item.array.push(object)
                }
            })


        }

        localStorage.setItem('userArray', JSON.stringify(userArray))
        localStorage.setItem('loginArray', JSON.stringify(loginArray))
        console.log(userArray);
    }



    return (
        <>
            {appleApi.length !== 0
                ? 
                appleApi[0].airpods.map(item => {
                    if (item.id === +id) {
                        return (
                            <div>
                                <div className="airpodspage_block">
                                    <div
                                        className="airpods_background"
                                        style={{
                                            backgroundPositionX: "center",
                                            // backgroundPositionY: "50px",
                                            backgroundRepeat: "no-repeat",
                                            backgroundImage: `url(${item.backgroundImage})`,
                                            textAlign: "center",
                                        }}>
                                        {/* <h2 style={{color: `${item.information.fontColor}`}}>{item.name}</h2> */}
                                    </div>
                                    <div className="airpodspage_descriptions" style={{ background: `${item.backgoundColor}`, color: `${item.fontColor}` }}>
                                        <div className="information_block">
                                            <h2>{item.name}</h2>
                                            <h1 className="product_mainText">{item.mainText}</h1>
                                            <h3 className="product_description">{item.description}</h3>
                                            <p style={{ color: "#767676", fontSize: 20, fontWeight: 600 }}>От {item.price} ₸</p>
                                        </div>
                                        <div className="product_info">
                                            <div className="airpodsInfo_block">
                                                <div className="product_item_airpods">
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.audio_img} />
                                                        <p>{item.information.audio}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.noise_img} />
                                                        <p>{item.information.noise}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.water_resistent_img} />
                                                        <p>{item.information.water_resistent}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.wireless_charging_img} />
                                                        <p>{item.information.wireless_charging}</p>
                                                    </div>
                                                    <div className="item_info_last">
                                                        <h2>{item.information.battery_main}</h2>
                                                        <p>{item.information.battery}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="buy_product_block">
                                        <div className="product_appearance">
                                            <div className="product_appearance_img">
                                                <img className="for_mobile_productImg" style={{ width: 300 }} src={item.airpods_color1} />
                                            </div>
                                        </div>
                                        <div className="product_dates">
                                            <div className="chip_block">
                                                <h2>{item.name}</h2>
                                            </div>

                                            <div className="for_price_block">
                                                <h1>{newPrice} ₸</h1>
                                            </div>
                                            <Link to={'/basket/products'}>
                                                <Button onClick={buyProduct}>Купить</Button>
                                            </Link>
                                        </div>

                                    </div>

                                    <div className="airpods_info_block">
                                        <div className="main_description">
                                            <h1 className="for_mobile_main_text">Мгновенная настройка. Легко слушать.</h1>
                                            <p className="for_mobile_text">Наушники AirPods подключаются немедленно, и звук легко переключается между iPhone, Apple Watch, Mac и iPad. Простая настройка, волшебный результаты.</p>
                                        </div>
                                        <div className="airpods__img">
                                            {/* <img src="../AirPods/airpods_large.jpg" style={{width: 450}} /> */}
                                            <img src={item.information.gif} className="airpods_gif" />
                                        </div>
                                    </div>

                                    <Benefits />
                                </div>
                            </div>
                        )
                    }
                })
                :
                null
            }

        </>
    )
}