import React, { lazy } from 'react';
import { AirPods } from '../../AirPods/AirPods';
import { AirProducts } from '../../AirPods/AirProducts/AirProducts';
import { IPad } from '../../iPad/IPad';
import { IPadProducts } from '../../iPad/iPadProducts/IPadProducts';
import { IPhone } from '../../iPhone/IPhone';
import { IPhoneProducts } from '../../iPhone/iPhoneProducts/IPhoneProducts';
import { Mac } from '../../Mac/Mac';
import { MacProducts } from '../../Mac/MacProducts/MacProducts';
import { Main } from '../../Main/Main';
import { Search } from '../../Search/Search';
import { Watch } from '../../Watch/Watch';
import { WatchProducts } from '../../Watch/WatchProducts/WatchProducts';

export const routes = [
    {path: 'mac', element: <Mac />,},
    {path: "ipad", element: <IPad />},
    {path: "iphone", element: <IPhone />},
    {path: "watch", element: <Watch />},
    {path: "airpods", element: <AirPods />},
    {path: "", element: <Main />},
    {path: "mac/:id", element: <MacProducts />},
    {path: "ipad/:id", element: <IPadProducts />},
    {path: "iphone/:id", element: <IPhoneProducts />},
    {path: "watch/:id", element: <WatchProducts />},
    {path: "airpods/:id", element: <AirProducts />},
    {path: "search", element: <Search />},
    {path: "*", element: <Main />},
]