import React, { useContext, useEffect, useState } from 'react'
import { Routes } from 'react-router';
import { Route } from 'react-router';
import { AirPods } from '../AirPods/AirPods';
import { AirProducts } from '../AirPods/AirProducts/AirProducts';
import { Basket } from '../Basket/Basket';
import { Products } from '../Basket/pages/Products/Products';
import { Buy } from '../Basket/pages/Buy/Buy';
import { Header } from '../Header/Header';
import { IPad } from '../iPad/IPad';
import { IPadProducts } from '../iPad/iPadProducts/IPadProducts';
import { IPhone } from '../iPhone/IPhone';
import { IPhoneProducts } from '../iPhone/iPhoneProducts/IPhoneProducts';
import { Login } from '../Login/Login';
import { Mac } from '../Mac/Mac';
import { MacProducts } from '../Mac/MacProducts/MacProducts';
import { Main } from '../Main/Main';
import { Search } from '../Search/Search';
import { AuthContext } from '../UI/context';
import { Watch } from '../Watch/Watch';
import { WatchProducts } from '../Watch/WatchProducts/WatchProducts';
import { Registration } from '../Registration/Registration';
import { Payment } from '../Basket/payment/Payment';
import { Success } from '../Basket/payment/success/Success';

export const AppRouter = () => {
    const { isAuth, setIsAuth } = useContext(AuthContext);

    //////userArray

    const [userArray, setUserArray] = useState(
        JSON.parse(localStorage.getItem('userArray'))
    )

    useEffect(() => {
        localStorage.setItem('userArray', JSON.stringify(userArray))
    }, [userArray])



    // Login
    const [loginArray, setLoginArray] = useState(
        JSON.parse(localStorage.getItem('loginArray'))
    )

    useEffect(() => {
        localStorage.setItem('loginArray', JSON.stringify(loginArray))
    }, [loginArray])




    return (
        isAuth
            ?
            <Routes>
                <Route path={"mac"} element={<Mac />} />
                <Route path={"ipad"} element={<IPad />} />
                <Route path={"iphone"} element={<IPhone />} />
                <Route path={"watch"} element={<Watch />} />
                <Route path={"airpods"} element={<AirPods />} />
                <Route path={"mac/:id"} element={<MacProducts loginArray={loginArray} userArray={userArray} />} />
                <Route path={"ipad/:id"} element={<IPadProducts loginArray={loginArray} userArray={userArray} />} />
                <Route path={"iphone/:id"} element={<IPhoneProducts loginArray={loginArray} userArray={userArray} />} />
                <Route path={"watch/:id"} element={<WatchProducts loginArray={loginArray} userArray={userArray} />} />
                <Route path={"airpods/:id"} element={<AirProducts loginArray={loginArray} userArray={userArray} />} />
                <Route path={"search"} element={<Search />} />
                <Route path={"basket/"} element={<Basket userArray={userArray} loginArray={loginArray} />} >
                    <Route path={"products"} element={<Products userArray={userArray} loginArray={loginArray} />} />
                    <Route path={"buy"} element={<Buy loginArray={loginArray} userArray={userArray} />} />
                </Route>
                <Route path={"payment"} element={<Payment loginArray={loginArray} userArray={userArray} />} />
                <Route path={"success"} element={<Success />} />
                <Route path="*" element={<Main loginArray={loginArray} />} />
            </Routes>
            :
            <Routes>
                    <Route path="login" element={<Login userArray={userArray} loginArray={loginArray} />} />
                    <Route path="*" element={<Login userArray={userArray} loginArray={loginArray} />} />
                    <Route path="" element={<Registration userArray={userArray} />} />
                    <Route path="registration/login" element={<Login userArray={userArray} loginArray={loginArray} />} />
                    <Route path="registration" element={<Registration userArray={userArray} />} />
                    <Route path="login/registration" element={<Registration userArray={userArray} />} />
                </Routes>
    )
}