import React, { useContext, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '../UI/button/Button'
import { AuthContext } from '../UI/context'
import "./Login.css"


export const Login = ({ userArray, loginArray }) => {

    console.log(userArray);

    const { isAuth, setIsAuth } = useContext(AuthContext)


    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [emailDirty, setEmailDirty] = useState(false)
    const [passwordDirty, setPasswordDirty] = useState(false)
    const [emailError, setEmailError] = useState('Логин не может быть пустым!')
    const [passwordError, setPasswordError] = useState("Пароль не может быть пустым!")
    const [formValid, setFormValid] = useState(false)


    const emailHandler = (e) => {
        setEmail(e.target.value)
        const re = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
        if (!re.test(String(e.target.value).toLowerCase())) {
            setEmailError('Некорректный логин!')
        } else {
            setEmailError('')
        }
    }

    const passwordHandler = (e) => {
        setPassword(e.target.value);
        if (e.target.value.length < 3 || e.target.value.length > 12) {
            setPasswordError('Пароль должен быть длинее 3 и  меньше 12!')
            if (!e.target.value) {
                setPasswordError('Пароль не может быть пустым!')
            }
        } else {
            setPasswordError('')
        }
    }

    
    const blurHandler = (e) => {
        switch (e.target.name) {
            case "email":
                setEmailDirty(true);
                break;
            case 'password':
                setPasswordDirty(true);
                break;
        }
    }


    useEffect(() => {
        if (emailError || passwordError) {
            setFormValid(false)
        } else {
            setFormValid(true)
        }
    }, [emailError, passwordError])




    const login = (event) => {
        event.preventDefault();
        userArray.map(item => {
            if (email == item.email && password == item.password) {
                setIsAuth(true)
                localStorage.setItem('auth', 'true')

                const loginObject = {
                    login: email,
                    password: password
                }

                loginArray.splice(0, 1)

                loginArray.push(loginObject)

            } else if ( email === item.email && password !== item.password) {
                setPasswordError("Вы не зарегистрировались или неправильный пароль. Попробуйте ещё раз");
            }
        })

        localStorage.setItem('loginArray', JSON.stringify(loginArray))
    }

    return (
        <div className="login_block">
            <div className="login_card">
                <h1>Страница для Логина</h1>
                <form className="login_form" onSubmit={login}>
                    {(emailDirty && emailError) && <div className="error_text">{emailError}</div>}
                    <input onChange={e => emailHandler(e)} value={email} onBlur={e => blurHandler(e)} name="email" className="login_input" type="text" placeholder="Введите логин..." />
                    {(passwordDirty && passwordError) && <div className="error_text">{passwordError}</div>}
                    <input onChange={e => passwordHandler(e)} value={password} onBlur={e => blurHandler(e)} name="password" className="login_input" type="password" placeholder="Введите пароль..." />
                    <button className="login_button" disabled={!formValid}>Войти</button>
                </form>
                <p>У вас ещё нет аккаунта? <Link to={"registration"}>Зарегистрироваться</Link></p>
            </div>
        </div>
    )
}