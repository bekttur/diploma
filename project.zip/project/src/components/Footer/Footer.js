import { Link } from "react-router-dom"
import "./Footer.css"

export const Footer = () => {
    return (
        <footer>
            <div className="footer_block">
                <div className="first_block">
                    <p>Товарные знаки и авторские права Главной лиги бейсбола используются с разрешения MLB Advanced Media, L.P. Все права защищены.</p>
                </div>
                <h3 style={{textAlign: "center"}}>Bektur Askarov</h3>
                <div className="last_block">
                    <p>Copyright © 2022 Apple Inc. All rights reserved.</p>
                    <p>Kazakhstan</p>
                </div>
            </div>
        </footer>
    )

}