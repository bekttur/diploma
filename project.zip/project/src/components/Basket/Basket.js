import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, Outlet, useParams } from 'react-router-dom';
import "./Basket.css"


export const Basket = ({ userArray, loginArray }) => {

    const [disabled, setDisabled] = useState(false)
    const [empty, setEmpty] = useState(false);

    const [basketError, setBasketError] = useState('')

    const [params, setParams] = useState("buy");

    const [payment, setPayment] = useState(false);

    const [productsArray, setProductsArray] = useState([]);




    userArray.map((item, i) => {
        if (item.email == loginArray[0].login) {
            item.array.map(productItem => {
                productsArray.push(productItem)
            })
        }
    })

    const totalPrice = productsArray.reduce((acc, product) => acc += product.price, 0)


    useEffect(() => {
        if (productsArray.length == 0) {
            setDisabled(true)
            setEmpty(true)
            setBasketError("Корзина пусто!")
        } else {
            setDisabled(false)
        }
    }, [productsArray])

    const [isProductActive, setIsProductActive] = useState(true)
    const [isBuyActive, setIsBuyActive] = useState(false)

    const ProductActive = () => {
        setIsProductActive(true)
        setIsBuyActive(false)
    }

    const BuyActive = () => {
        setIsBuyActive(true)
        setIsProductActive(false)
    }

    const NextPage = () => {

        if (isProductActive) {
            setIsProductActive(false);
            setIsBuyActive(true);
            setPayment(true);

        } else {
            setIsProductActive(true)
            setIsBuyActive(false);
            setPayment(true);
        }
    }

    return (
        <div className="basket_block">
            <div className="basket_container">
                <div className="logo_block">
                    <Link to={"/"}>
                        <img className="logo_image" src="../icon/apple_logo.png" />
                    </Link>
                </div>
                <nav className="basket_navbar">
                    <ul className="nav_item">
                        <li onClick={ProductActive}>
                            <Link className="nav_link" to={"/basket/products"}>
                                <div className="nav_page" style={{ backgroundColor: isProductActive ? "#006EDB" : "white", color: isProductActive ? "white" : "#006EDB" }}>
                                    <p>Корзина</p>
                                </div>
                            </Link>
                        </li>
                        <li onClick={BuyActive}>
                            <Link className="nav_link" to={"/basket/buy"}>
                                <div className="nav_page" style={{ backgroundColor: isBuyActive ? "#006EDB" : "white", color: isBuyActive ? "white" : "#006EDB" }}>
                                    <p>Подтверждение</p>
                                </div>
                            </Link>
                        </li>
                    </ul>
                </nav>
                {(basketError) && <div className="basket_empty">{basketError}</div>}
                <Outlet />
                <div className="checkout_block">
                    <div style={{ display: payment ? "none" : "block" }}>
                        <Link to={`/basket/${params}`}>
                            <button disabled={disabled} onClick={NextPage} className="checkout_btn">Оформить заказ</button>
                        </Link>
                    </div>
                    <div>
                        <a
                            href="http://localhost:3000/payment"
                            style={{ display: payment ? "block" : "none", paddingTop: 20}}
                            disabled={disabled}
                            className="checkout_btn"
                        >Перейти к оплате</a>
                    </div>
                </div>
            </div>



        </div>
    )
}