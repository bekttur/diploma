import "./Products.css"
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export const Products = ({ loginArray, userArray }) => {

    // for return 
    const [productsArray, setProductsArray2] = useState([]);


    userArray.map((item, i) => {
        if (item.email == loginArray[0].login) {
            item.array.map(productItem => {
                productsArray.push(productItem)
            })
        }
    })


    const deleteItem = (index, e) => () => {
        console.log(index)

        userArray.map(item => {
            if (item.email == loginArray[0].login) {
                item.array.map((productItem, i) => {
                    if (i == index) {
                        console.log(productItem)
                        item.array.splice(i, 1);
                        console.log(item.array);
                        localStorage.setItem('userArray', JSON.stringify(userArray))
                    }
                })
            }
        })
        window.location.reload()
    }



    return (
        <div className="products_block">
            <div className="products_container">
                {productsArray.map((item, index) => {
                    if (item.color) {
                        return (
                            <div className="products_card">
                                <div className="products_image">
                                    <img style={{ width: 80 }} src={item.image1} />
                                </div>
                                <div className="product_name">
                                    <p className="product_data">{item.name}</p>
                                </div>
                                <div className="products_price">
                                    <div>
                                        <button type="submit" onClick={deleteItem(index)} className="delete_btn">Удалить</button>
                                    </div>
                                    <p className="product_data">{item.price}</p>
                                </div>
                            </div>
                        )
                    } else {
                        return (
                            <div className="products_card">
                                <div className="products_image">
                                    <img style={{ width: 80 }} src={item.image2} />
                                </div>
                                <div className="product_name">
                                    <p className="product_data">{item.name}</p>
                                </div>
                                <div className="products_price">
                                    <div>
                                        <button onClick={deleteItem(index)} className="delete_btn">Удалить</button>
                                    </div>
                                    <p className="product_data_price">{item.price} ₸</p>
                                </div>
                            </div>
                        )
                    }
                })}
            </div>

        </div>
    )
}