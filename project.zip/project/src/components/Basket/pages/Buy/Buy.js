
import { useContext, useState } from "react"
import { useSelector } from "react-redux"
import { AuthContext } from "../../../UI/context"
import "./Buy.css"

export const Buy = ({ userArray, loginArray }) => {

    const [productsArray, setProductsArray] = useState([]);


    userArray.map((item, i) => {
        if (item.email == loginArray[0].login) {
            item.array.map(productItem => {
                productsArray.push(productItem)
            })
        }
    })

    const totalPrice = productsArray.reduce((acc, product) => acc += product.price, 0)




    return (
        <div className="products_block">
            <div className="products_container">
                <div className="contact_block">
                    <div className="user_image">
                        <img style={{ width: 60 }} src="../../../icon/user_icon.png" />
                    </div>
                    <div className="user_name">
                        <p className="product_data">Контакты</p>
                        {userArray.map(item => {
                            if (item.email == loginArray[0].login) {
                                return (
                                    <p style={{ color: "#989898", marginTop: -15 }}>{item.email}, {item.name}, {item.phone}</p>
                                )
                            }
                        }
                        )}
                    </div>
                </div>
                {productsArray.map((item, index) => {
                    if (item.color) {
                        return (
                            <div className="products_card">
                                <div className="products_image">
                                    <img style={{ width: 80 }} src={item.image1} />
                                </div>
                                <div className="product_name">
                                    <p className="product_data">{item.name}</p>
                                </div>
                                <div className="products_price">
                                    <p className="product_data">{item.price}</p>
                                </div>
                            </div>
                        )
                    } else {
                        return (
                            <div className="products_card">
                                <div className="products_image">
                                    <img style={{ width: 80 }} src={item.image2} />
                                </div>
                                <div className="product_name">
                                    <p className="product_data">{item.name}</p>
                                </div>
                                <div className="products_price">
                                    <p className="product_data">{item.price}</p>
                                </div>
                            </div>
                        )
                    }
                })
                }
                <div className="final_price_block">
                    <div className="final_price_text">
                        <h3>Итого:</h3>
                        <h3>{totalPrice} ₸</h3>
                    </div>
                </div>
            </div>
        </div>
    )
}