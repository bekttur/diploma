import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./Payment.css"

export const Payment = ({ loginArray, userArray }) => {


    const [productsArray, setProductsArray] = useState([]);


    userArray.map((item, i) => {
        if (item.email == loginArray[0].login) {
            item.array.map(productItem => {
                productsArray.push(productItem)
            })
        }
    })

    const clearArray = () => {
        userArray.map((item, i) => {
            if (item.email == loginArray[0].login) {
                item.array.splice(0, item.array.length)
            }
        })

        localStorage.setItem('userArray', JSON.stringify(userArray))
        
    }



    const [cardNumber, setCardNumber] = useState('')
    const [termValue, setTermValue] = useState("")
    const [codeValue, setCodeValue] = useState("")
    const [cardNumberDirty, setCardNumberDirty] = useState(false)
    const [termDirty, setTermDirty] = useState(false)
    const [codeDirty, setCodeDirty] = useState(false)
    const [cardNumberError, setCardNumberError] = useState('Заполните это поле')
    const [termError, setTermError] = useState('Заполните это поле')
    const [codeError, setCodeError] = useState('Заполните это поле')
    const [formValid, setFormValid] = useState(false)

    const cardNumberHandler = (e) => {
        setCardNumber(e.target.value)
        if (e.target.value.length < 12) {
            setCardNumberError('Проверьте номер карты')
            if (!e.target.value) {
                setCardNumberError('Заполните это поле')
            }
        } else if (e.target.value.length == 12) {
            setCardNumberError('')
        }
    }

    const termValueHandler = (e) => {
        setTermValue(e.target.value)
        if (e.target.value.length < 5) {
            setTermError("Проверьте дату")
            if (!e.target.value) {
                setTermError('Заполните это поле')
            }

        } else if (e.target.value.length == 5) {
            setTermError('')
        }
    }

    const codeValueHandler = (e) => {
        setCodeValue(e.target.value)
        if (e.target.value.length < 3 || e.target.value.length > 3) {
            setCodeError('Проверьте поле')
            if (!e.target.value) {
                setCodeError('Заполните это поле')
            }
        } else if (e.target.value.length == 3) {
            setCodeError('')
        }
    }

    const blurHandler = (e) => {
        switch (e.target.name) {
            case "cardNumber":
                setCardNumberDirty(true);
                break;
            case 'term':
                setTermDirty(true);
                break;
            case 'code':
                setCodeDirty(true);
                break;
        }
    }

    useEffect(() => {
        if (cardNumberError || termError || codeError) {
            setFormValid(false)
        } else {
            setFormValid(true)

        }
    }, [cardNumberError, termError, codeError])







    return (
        <>
            {userArray.map(item => {
                if (item.email == loginArray[0].login) {
                    const totalPrice = item.array.reduce((acc, product) => acc += product.price, 0)

                    return (
                        <div className="payment_container">
                            <div className="payment_nav">
                                <h2 className="for_mobile_txt">К оплате {totalPrice}₸</h2>
                            </div>
                            <div className="payment_form">
                                <div className="payment_date">
                                    <form method="post">
                                        <div className="card_for_payment">
                                            <div>
                                                <img style={{ width: 40, marginRight: 15 }} src="../../../icon/card_payment.png" />
                                            </div>
                                            <p className="main_txt">Оплата картой</p>
                                        </div>
                                        {(cardNumberDirty && cardNumberError) && <div className="error_text">{cardNumberError}</div>}
                                        <input maxLength={12} name="cardNumber" onChange={(e) => cardNumberHandler(e)} className="payment_input" onBlur={e => blurHandler(e)} type="text" placeholder="Номер карты" />
                                        <div className="card_date">
                                            <div>
                                                <input name="term" maxLength={5} onChange={(e) => termValueHandler(e)} className="payment_input_date" onBlur={e => blurHandler(e)} style={{ marginRight: "3%" }} type="text" placeholder="MM/YY" />
                                                {(termDirty && termError) && <div className="error_text">{termError}</div>}
                                            </div>
                                            <div>
                                                <input name="code" maxLength={3} onChange={(e) => codeValueHandler(e)} className="payment_input_date" onBlur={e => blurHandler(e)} type="text" placeholder="CVC/CVV" />
                                                {(codeDirty && codeError) && <div className="error_text">{codeError}</div>}
                                            </div>
                                        </div>
                                        <Link to={'/success'}>
                                            <button disabled={!formValid} onClick={clearArray} className="checkout_btn">Оплатить</button>
                                        </Link>
                                    </form>
                                </div>
                            </div>
                        </div>
                    )
                }
            })}
        </>

    )
}
