import React from 'react'
import "./Success.css"

export const Success = () => {
    return (
        <div class="success_main_block">
            <div class="success_card_block">
                <div class="success_card_img">
                    <div class="success_wrapper"> <svg class="animated-check" viewBox="0 0 24 24">
                        <path d="M4.1 12.7L9 17.6 20.3 6.3" fill="none" /> </svg>
                    </div>
                </div>
                <div class="success_card_text">
                    <h2>Успешно оплачен</h2>
                    <p className="success_txt">Спасибо за покупку )</p>
                </div>
            </div>
        </div>
    )
}