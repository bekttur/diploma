import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Card } from '../Mac/card/Card'
import { Appearance } from '../Mac/card/images/appearance'
import { Price } from '../Mac/card/price/Price'
import { Button } from '../UI/button/Button'
import './Search.css'


export const Search = () => {


    const apple = [
        {
            "id": 1,
            "name": "MacBook Air",
            "price": 466990,
            "image": "macbook/compare_mba.png",
            "router": "/mac/"
        },
        {
            "id": 2,
            "name": "New MacBook Air",
            "price": 560490,
            "image": "macbook/compare_mbam2.png",
            "router": "/mac/"
        },
        {
            "id": 3,
            "name": "MacBook Pro 13”",
            "price": 607000,
            "image": "./macbook/compare_mbp13.png",
            "router": "/mac/"
        },
        {
            "id": 4,
            "name": "MacBook Pro 14” и 16”",
            "price": 934490,
            "image": "./macbook/compare_mbp14_16.png",
            "router": "/mac/"
        },
        {
            "id": 5,
            "name": "iMac 24””",
            "price": 607290,
            "image": "./macbook/compare_imac24.png",
            "router": "/mac/"
        },
        {
            "id": 6,
            "name": "Mac mini",
            "price": 326990,
            "image": "./macbook/compare_macmini.png",
            "router": "/mac/"
        },
        {
            "id": 7,
            "name": "Mac Studio",
            "price": 952490,
            "image": "./macbook/compare_macstudio.png",
            "router": "/mac/"
        },
        {
            "id": 8,
            "name": "Mac Pro",
            "price": 2858990,
            "image": "./macbook/compare_macpro.png",
            "router": "/mac/"
        },
        {
            "id": 9,
            "name": "iPad Pro",
            "price": 368790,
            "image": "../iPad/products/compare_ipad_pro.png",
            "router": "/ipad/"
        },
        {
            "id": 10,
            "name": "iPad Air",
            "price": 276490,
            "image": "../iPad/products/compare_ipad_air.png",
            "router": "/ipad/"
        },
        {
            "id": 11,
            "name": "iPad",
            "price": 151890,
            "image": "../iPad/products/compare_ipad_10.png",
            "router": "/ipad/"
        },
        {
            "id": 12,
            "name": "iPad Mini",
            "price": 230290,
            "image": "../iPad/products/compare_ipad_mini.png",
            "router": "/ipad/"
        },
        {
            "id": 13,
            "name": "iPhone 13 Pro",
            "opacity": 1,
            "price": 368790,
            "image": "../iPhone/iphone_13_pro_img.jpg",
            "router": "/iphone/"
        },
        {
            "id": 14,
            "name": "iPhone 13",
            "opacity": 0,
            "price": 276490,
            "image": "../iPhone/compare_iphone_13.jpg",
            "router": "/iphone/"
        },
        {
            "id": 15,
            "name": "iPhone SE",
            "price": 151890,
            "image": "../iPhone/compare_iphone_se.jpg",
            "router": "/iphone/"
        },
        {
            "id": 16,
            "name": "iPhone 12",
            "price": 230290,
            "image": "../iPhone/compare_iphone_12.jpg",
            "router": "/iphone/"
        },
        {
            "id": 17,
            "name": "Apple Watch Серия 7",
            "name_img": "../Watch/logo_watch_s7.png",
            "price": 184090,
            "image": "../Watch/products/compare_s7.jpg",
            "router": "/watch/"
        },
        {
            "id": 18,
            "name": "Apple Watch SE",
            "name_img": "../Watch/logo-watch-se.png",
            "price": 128790,
            "image": "../Watch/products/compare_se.jpg",
            "router": "/watch/"
        },
        {
            "id": 19,
            "name": "Apple Watch Серия 3",
            "name_img": "../Watch/logo_series_3.png",
            "price": 91890,
            "image": "../Watch/products/compare_s3.jpg",
            "router": "/watch/"
        },
        {
            "id": 20,
            "name": "AirPods",
            "price": 60390,
            "image": "../AirPods/products/compare_airpods_2.png",
            "router": "/airpods/"
        },
        {
            "id": 21,
            "name": "AirPods",
            "price": 83790,
            "image": "../AirPods/products/compare_airpods_3.png",
            "router": "/airpods/"
        },
        {
            "id": 22,
            "name": "AirPods Pro",
            "price": 116525,
            "image": "../AirPods/products/compare_airpods_pro.png",
            "router": "/airpods/"
        },
        {
            "id": 23,
            "name": "AirPods Max",
            "price": 256890,
            "image": "../AirPods/products/compare_airpods_max.png",
            "router": "/airpods/"
        },
    ]

    const [valueName, setValueName] = useState('')




    const filteredProducts = apple.filter(product => {
        return (
            product.name.toLowerCase().includes(valueName.toLowerCase())
        )
    })

    return (
        <div className="search_container">
            <div className="search_form">
                <form className="search">
                    <input type="text" className="search_input" onChange={(e) => setValueName(e.target.value)} placeholder="Поиск" />
                </form>
            </div>
            <div className="search_block">
                <div className="search_item">
                    {filteredProducts.map(item => {
                        return (
                            <div className="for_mobile">
                                <Card>
                                    <Link to={`${item.router}` + `${item.id}`}>
                                        <div style={{ marginBottom: 20 }}>
                                            <Appearance>{item.image}</Appearance>
                                        </div>
                                        {item.name}
                                        <Price>{item.price}</Price>
                                        <Button>Купить</Button>
                                    </Link>
                                </Card>
                            </div>

                        )
                    })}
                </div>
            </div>
        </div>

    )
}



