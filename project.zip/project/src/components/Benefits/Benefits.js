import React from "react";
import "./Benefits.css"

export const Benefits = () => {
    return (
        <div className="benefits_container">
            <div className="benefits_item">
                <div className="benefits_image">
                    <img src="../icon/icon_delivery.png" />
                </div>
                <div className="benefits_text">
                    <h3>Бесплатная доставка</h3>
                    <p>и бесплатный возврат. См. оформление заказа для дат доставки.</p>
                </div>
            </div>
            <div className="benefits_item">
                <div className="benefits_image">
                    <img src="../icon/icon_financing.png" />
                </div>
                <div className="benefits_text">
                    <h3>Платите ежемесячно по цене 0%</h3>
                    <p>Вы можете оплатить с течением времени, когда решите оформить рассрочку</p>
                </div>
            </div>
            <div className="benefits_item">
                <div className="benefits_image">
                    <img src="../icon/icon_engraving.png" />
                </div>
                <div className="benefits_text">
                    <h3>Получите помощь в покупке</h3>
                    <p>Есть вопрос? <br />Позвоните по телефону 7-(708)-540-42-08</p>
                </div>
            </div>
        </div>
    )
}