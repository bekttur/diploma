import React from "react";
import { Link } from "react-router-dom";
import "./MacbookPro.css"

export const MacbookPro = () => {
    return (
        <div className="wrapper">
            <div className="main_block">
                <div className="macbook_pro_block">
                    <div className="macbook_descriptions">
                        <h1 className="macbook_descriptions_h1">MacBook Pro 13</h1>

                        <Link to={"/mac/3"}>
                            <p className="link_item">Купить</p>
                        </Link>

                    </div>
                </div>
            </div>

        </div>
    )
}