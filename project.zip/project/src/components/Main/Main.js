import { MacbookAir } from "./MacbookAir/MacbookAir";
import { MacbookPro } from "./MacbookPro/MacbookPro";
import "./Main.css"
import { Benefits } from "../Benefits/Benefits"
import { Link } from "react-router-dom";


export const Main = ({loginArray}) => {

    
    console.log(loginArray);


    return (
        <div>
            <MacbookPro />
            <MacbookAir />
            <div className="products_block">
                <div className="product_grid_block">
                    <div className="product_item_block iPad">
                        <h2 style={{ color: "white", textAlign: "center" }}>iPad Air</h2>
                        <p className="description">Легкий.Яркий.Полный силы.</p>
                        <Link to={"/ipad/10"}>
                            <p className="link_item">Купить</p>
                        </Link>
                    </div>
                    <div className="product_item_block watch">
                        <h2 style={{ color: "black", textAlign: "center" }}>Watch</h2>
                        <p className="description">Это наш самый большой дисплей.</p>
                        <Link to={"/watch"}>
                            <p className="link_item">Купить</p>
                        </Link>
                    </div>
                    <div className="product_item_block iPhone13">
                        <h2 style={{ color: "black", textAlign: "center" }}>iPhone 13</h2>
                        <p className="description">Ваша новая супер сила.</p>
                        <Link to={"/iphone/14"}>
                            <p className="link_item">Купить</p>
                        </Link>
                    </div>
                    <div className="product_item_block iPhone13_Pro">
                        <h2 style={{ color: "black", textAlign: "center" }}>iPhone 13 Pro</h2>
                        <p className="description">Киноэффект.</p>
                        <Link to={"/iphone/13"}>
                            <p className="link_item">Купить</p>
                        </Link>
                    </div>
                </div>
            </div>
            <Benefits />
        </div>
    )
}