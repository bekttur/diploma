import React from "react";
import { Link } from "react-router-dom";
import "./MacbookAir.css"

export const MacbookAir = () => {
    return (
            <div className="macbook_air_block">
                <div className="macbook_air_descriptions">
                    <h1 className="macbook_air_descriptions_h1">MacBook Air</h1>

                    <Link to={"/mac/2"}>
                        <p className="link_item">Купить</p>
                    </Link>

                </div>
            </div>

    )
}