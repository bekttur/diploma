import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Price } from "../../Mac/card/price/Price";
import { Button } from "../../UI/button/Button";

import "./IPadAir.css"
import { getProducts } from "../../../API/productsAPI";

export const IPadAir = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    console.log(appleApi);
    
    return (
        <div>
            <Link to={"/ipad/10"}>
                <div className="iPadAir_container">
                    <div className="iPadAir_text_block">
                        <h1 className="main_paragraf">iPad Air</h1>
                        <p className="description">Легкий.</p>
                        <p className="description">Яркий.</p>
                        <p className="description">Полный силы.</p>
                        <div style={{ color: "white" }}>
                            <Price>{appleApi.length !== 0
                                ?
                                appleApi[0].ipad[1].price
                                :
                                null}</Price>
                        </div>
                        <Button>Купить</Button>
                    </div>
                    <div className="iPadAir_image_block">
                        <img className="iPadAir_img" src="https://www.apple.com/v/ipad/home/by/images/overview/hero/ipad_air__d794tkovmk02_large.jpg" />
                    </div>
                </div>
            </Link>
        </div>
    )
}