import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Price } from "../../Mac/card/price/Price";
import { Button } from "../../UI/button/Button";
import "./iPadPro.css"
import { getProducts } from "../../../API/productsAPI";

export const IPadPro = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    console.log(appleApi);

    return (
        <div style={{ backgroundColor: "white" }}>
            <Link to={"/ipad/9"}>
                <div className="iPadPro_container">
                    <div className="iPadPro_text_block">
                        <h1 className="main_paragraf">iPad Pro</h1>
                        <p className="description">Доступно в июле.</p>
                        <div style={{ color: "white" }}>
                            <Price>{appleApi.length !== 0
                                ?
                                appleApi[0].ipad[0].price
                                :
                                null}</Price>
                        </div>
                        <Button>Купить</Button>
                    </div>

                </div>
            </Link>
        </div>

    )
}