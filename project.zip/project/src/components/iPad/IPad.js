import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Benefits } from "../Benefits/Benefits";
import { Card } from "../Mac/card/Card";
import { Appearance } from "../Mac/card/images/appearance";
import { Price } from "../Mac/card/price/Price";
import { Button } from "../UI/button/Button";
import "./IPad.css"
import { getProducts } from "../../API/productsAPI";

import { IPadAir } from "./iPadAir/IPadAir";
import { IPadPro } from "./iPadPro/iPadPro";



export const IPad = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    console.log(appleApi);
    // const IPadArray = apple[0].ipad;
    return (
        <div>
            <IPadAir />
            <IPadPro />
            <div className="ipad_block">
                <div className="ipad_container">
                    <div className="ipad_description">
                        <h1 className="main_paragraf">Какой iPad подходит именно вам?</h1>
                    </div>
                    <div className="ipad_items">
                        <div className="products">
                            {appleApi.length !== 0
                                ?
                                appleApi[0].ipad.map(item => {
                                    return (
                                        <Card>
                                            <Link to={"/ipad/" + `${item.id}`}>
                                                <div style={{ marginBottom: 20 }}>
                                                    <Appearance>{item.image}</Appearance>
                                                </div>
                                                {item.name}
                                                <Price>{item.price}</Price>
                                                <Button>Купить</Button>
                                            </Link>
                                        </Card>
                                    )

                                })
                                :
                                null
                            }


                        </div>
                    </div>

                    <div className="ios15_block">
                        <div className="ios15_text">
                            <h2 className="main_paragraf">iPadOS 15</h2>
                            <p style={{ fontSize: 20 }}>Чудеса творения. С легкостью.</p>
                        </div>
                    </div>

                    <Benefits />

                    {/* <div className="ios_ipad_block">
                        <div className="ios_text">
                            <h2>iPadOS 16</h2>
                            <p style={{ fontSize: 20, fontWeight: 600 }}>Невероятно способный.<br /> Безошибочно iPad.</p>
                        </div>
                        <div className="ios_background">
                            <img className="ios_img" src="../iPad/ipados16.jpg" />
                        </div>
                    </div> */}
                </div>
            </div>
        </div>

    )
}