import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import "./IPadProducts.css"
import { apple } from "../../apple"
import { Link } from "react-router-dom";
import { Button } from "../../UI/button/Button";
import { getProducts } from "../../../API/productsAPI";


export const IPadProducts = ({ userArray, loginArray }) => {
    let { id } = useParams();

    let productId = id - 9;

    const [appleApi, setApple] = useState([]);
    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);
    console.log(appleApi);

    const [newPrice, setNewPrice] = useState(apple[0].ipad[productId].price)

    const [isGrayIpad, setIsGrayIpad] = useState(true)
    const [isHoverMemoryIpad, setIsHoverMemoryIpad] = useState(true)
    const [isHoverStorageIpad, setIsHoverStorageIpad] = useState(true)

    const buyProduct = () => {
        if (productId + 9 == id) {
            const object = {
                id: appleApi[0].ipad[productId].id,
                name: appleApi[0].ipad[productId].name,
                price: newPrice,
                color: isGrayIpad,
                image1: appleApi[0].ipad[productId].ipad_color1,
                image2: appleApi[0].ipad[productId].ipad_color2,
                memory: isHoverMemoryIpad,
                storage: isHoverStorageIpad
            }

            userArray.map(item => {
                if (loginArray[0].login == item.email) {
                    item.array.push(object)
                }
            })
        }

        localStorage.setItem('userArray', JSON.stringify(userArray))
        localStorage.setItem('loginArray', JSON.stringify(loginArray))
        console.log(userArray);
    }






    const onChangeValueIpad = (event) => {
        if (event.target.value == "gray") {
            setIsGrayIpad(true)
            console.log(newPrice);
        } else {
            setIsGrayIpad(false)
        }
    }

    const onClickMemoryIpad = () => {
        if (isHoverMemoryIpad == true) {
            setIsHoverMemoryIpad(false)
            setNewPrice(newPrice + 25000)
        } else {
            setIsHoverMemoryIpad(true)
            setNewPrice(newPrice - 25000)
        }
    }

    const onClickStorageIpad = () => {
        if (isHoverStorageIpad == true) {
            setIsHoverStorageIpad(false)
            setNewPrice(newPrice + 25000)
        } else {
            setIsHoverStorageIpad(true)
            setNewPrice(newPrice - 25000)
        }
    }



    return (
        <>
            {appleApi.length !== 0
                ?
                appleApi[0].ipad.map(item => {
                    console.log(item.id === +id)
                    if (item.id === +id) {
                        return (
                            <div>
                                <div className="ipadpage_block">
                                    <div
                                        className="ipad_background"
                                        style={{
                                            height: 500,
                                            backgroundPositionX: "center",
                                            // backgroundPositionY: "50%",
                                            backgroundRepeat: "no-repeat",
                                            backgroundSize: "cover",
                                            backgroundImage: `url(${item.backgroundImage})`
                                        }}>
                                    </div>
                                    <div className="ipadpage_descriptions" style={{ background: `${item.backgoundColor}`, color: `${item.fontColor}` }}>
                                        <div className="information_block">
                                            <h2>{item.name}</h2>
                                            <h1 className="product_mainText" >{item.mainText}</h1>
                                            <h3 className="product_description" >{item.description}</h3>
                                            <p style={{ color: "#767676", fontSize: 20, fontWeight: 600 }}>От {item.price} ₸</p>
                                        </div>
                                        <div className="product_info">
                                            <div className="ipadInfo_block">
                                                <div className="product_item_ipad">
                                                    <div className="item_info">
                                                        <h3>{item.information.display}</h3>
                                                        <p>Дисплей</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.chip_img} />
                                                        <p>{item.information.chip}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.back_cameras_img} />
                                                        <p>{item.information.back_cameras}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img style={{ marginBottom: 15 }} className="info_image" src={item.information.USBC_img} />
                                                        <p>{item.information.USBC}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.cellular_img} />
                                                        <p>{item.information.cellular}</p>
                                                    </div>
                                                    <div>
                                                        <img style={{ paddingTop: 20, marginBottom: 15 }} className="info_image" src={item.information.pencil_img} />
                                                        <p>{item.information.pencil}</p>
                                                    </div>
                                                    <div>
                                                        <img className="info_image" src={item.information.magic_key_img} />
                                                        <p>{item.information.magic_key}</p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <div className="buy_product_block">
                                            <div className="product_appearance">
                                                <div className="product_appearance_img">
                                                    <img className="for_mobile_productImg" src={item.ipad_color1} style={{ display: isGrayIpad ? 'block' : 'none', width: 300 }} />
                                                    <img className="for_mobile_productImg" src={item.ipad_color2} style={{ display: isGrayIpad ? 'none' : 'block', width: 300 }} />
                                                </div>
                                                <div className="for_price_block">
                                                    <h1>{newPrice} ₸</h1>
                                                </div>
                                            </div>
                                            <div className="product_dates">
                                                <div className="chip_block">
                                                    <img src={item.information.chip_img} />
                                                </div>
                                                <div className="product_color" onChange={onChangeValueIpad}>
                                                    <h3>Цвет:</h3>
                                                    <label>
                                                        <img style={{ width: 30 }} src={item.color1} />
                                                        <input style={{ opacity: 0 }} type="radio" name="color" value={item.input_value1} />
                                                    </label>
                                                    <label>
                                                        <img style={{ width: 30 }} src={item.color2} />
                                                        <input style={{ opacity: 0 }} type="radio" name="color" value={item.input_value2} />
                                                    </label>
                                                </div>
                                                <div className="memory_date_block">
                                                    <h3>Память:</h3>
                                                    <p className="qwestion_for_date">Сколько память вам подходит?</p>
                                                    <label>
                                                        <div className="memory_card" onClick={onClickMemoryIpad} style={{ border: isHoverMemoryIpad ? "2px solid #0071e3" : "1px solid #86868b" }}>
                                                            <h3>64 ГБ единой памяти</h3>
                                                            <p style={{ opacity: isHoverMemoryIpad ? 0 : 1 }} >- 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="memory" />
                                                    </label>
                                                    <label>
                                                        <div className="memory_card" onClick={onClickMemoryIpad} style={{ border: isHoverMemoryIpad ? "1px solid #86868b" : "2px solid #0071e3" }}>
                                                            <h3>128 ГБ единой памяти</h3>
                                                            <p style={{ opacity: isHoverMemoryIpad ? 1 : 0 }} >+ 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="memory" />
                                                    </label>
                                                </div>
                                                <div className="storage_date_block">
                                                    <h3>Связь:</h3>
                                                    <label>
                                                        <div className="storage_card" onClick={onClickStorageIpad} style={{ border: isHoverStorageIpad ? "2px solid #0071e3" : "1px solid #86868b" }}>
                                                            <h3>Wi-Fi</h3>
                                                            <p style={{ opacity: isHoverStorageIpad ? 0 : 1 }} >- 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="storage" />
                                                    </label>
                                                    <label>
                                                        <div className="storage_card" onClick={onClickStorageIpad} style={{ border: isHoverStorageIpad ? "1px solid #86868b" : "2px solid #0071e3" }}>
                                                            <h3>Wi-Fi + Сотовый</h3>
                                                            <p style={{ opacity: isHoverStorageIpad ? 1 : 0 }} >+ 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="storage" />
                                                    </label>
                                                </div>
                                                <Link to={'/basket/products'}>
                                                    <Button onClick={buyProduct}>Купить</Button>
                                                </Link>
                                            </div>
                                        </div>

                                        <div className="memory_block">
                                            <p style={{ fontSize: 45, fontWeight: 900 }}>До {item.information.memory}</p>
                                            <p style={{ fontSize: 20, fontWeight: 600 }}>Возьмите с собой фотографии, фильмы, музыку и документы и откройте их мгновенно.</p>
                                        </div>
                                        <div className="magicKey_block">
                                            <div className="keyboard_description">
                                                <h1 className="keyboard_mainText">Magic Keyboard.<br /> Apple Pencil. Безграничные возможности.</h1>
                                                <p className="keyboard_paragraf">Apple Pencil, Magic Keyboard и Smart Keyboard Folio открывают еще больше способов использования iPad. Нарисуйте шедевр, сделайте заметки или составьте бизнес-план. Эти универсальные аксессуары предназначены для того, чтобы вывести вашу работу и творчество на новый уровень.</p>
                                            </div>
                                            <div className="keyboard_img">
                                                <img style={{ width: "50%" }} src={item.information.keyboard} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )
                    }
                })
                :
                null
            }

        </>
    )
}