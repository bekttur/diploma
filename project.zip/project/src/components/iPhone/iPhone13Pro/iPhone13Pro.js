import React, { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { Price } from "../../Mac/card/price/Price"
import { Button } from "../../UI/button/Button"
import "./iPhone13Pro.css"
import { getProducts } from "../../../API/productsAPI"


export const IPhone13Pro = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    console.log(appleApi);

    return (
        <div>
            <Link to={"/iphone/13"}>
                <div className="iPhone13Pro_block">
                    <div className="iPhone13Pro_text">
                        <img src="../iPhone/iphone_13_pro_logo.png" />
                        <Price>{appleApi.length !== 0
                            ?
                            appleApi[0].iphone[0].price
                            :
                            null}</Price>
                        <Button>Купить</Button>
                    </div>
                    <div className="iPhone13Pro_background">
                        <img className="iPhone13Pro_img" src="../iPhone/iphone_13_pro.png" />
                    </div>
                </div>
            </Link>
        </div>
    )
}