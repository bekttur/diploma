import React, { useEffect, useState } from "react"
import { Price } from "../Mac/card/price/Price"
import { Button } from "../UI/button/Button"
import "./IPhone.css"
import { IPhone13 } from "./iPhone13/IPhone13"
import { IPhone13Pro } from "./iPhone13Pro/iPhone13Pro"
import { Appearance } from "../Mac/card/images/appearance";
import { Benefits } from "../Benefits/Benefits"
import { Card } from "../Mac/card/Card"
import { Link } from "react-router-dom"
import { getProducts } from "../../API/productsAPI";




export const IPhone = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    console.log(appleApi);


    return (
        <div>
            <IPhone13Pro />
            <IPhone13 />
            <div className="iphone_block">
                <div className="iphone_container">
                    <div className="iphone_description">
                        <h1 className="main_paragraf">Какой iPhone вам подходит?</h1>
                    </div>
                    <div className="iphone_items">
                        <div className="products">
                            {appleApi.length !== 0
                                ?
                                appleApi[0].iphone.map((item) => {
                                    return (
                                        <div className="for_mobile">
                                            <Card>
                                                <Link to={"/iphone/" + `${item.id}`}>
                                                    <div style={{ marginBottom: 20 }}>
                                                        <Appearance>{item.image}</Appearance>
                                                    </div>
                                                    <img src={item.name} />

                                                    <Price>{item.price}</Price>
                                                    <Button>Купить</Button>
                                                </Link>
                                            </Card>
                                        </div>
                                    )
                                })
                                : null
                            }
                                
                        </div>
                    </div>
                    <div className="ios15_block">
                        <div className="ios15_text">
                            <h2>iOS 15</h2>
                            <p style={{ fontSize: 20 }}>На связи. В данный момент.</p>
                        </div>
                    </div>
                    <Benefits />
                    <div className="ios16_block">
                        <div className="ios16_text">
                            <h2>iOS 16</h2>
                            <p style={{ fontSize: 20 }}>Личность - это мощно.</p>
                        </div>
                        <div className="ios16_background">
                            <img className="ios16_img" src="../AccessoriesForPages/ios16.jpg" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}