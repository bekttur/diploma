import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import "./IPhoneProducts.css"
import { apple } from "../../apple"
import { Link } from "react-router-dom";
import { Button } from "../../UI/button/Button";
import { getProducts } from "../../../API/productsAPI";


export const IPhoneProducts = ({ userArray, loginArray }) => {
    let { id } = useParams();

    let productId = id - 13;

    const [appleApi, setApple] = useState([]);
    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    const [newPrice, setNewPrice] = useState(apple[0].iphone[productId].price)

    const [isGrayIphone, setIsGrayIphone] = useState(true)
    const [isHoverMemoryIphone, setIsHoverMemoryIphone] = useState(true)
    const [isHoverStorageIphone, setIsHoverStorageIphone] = useState(true)

    const [finalPrice, setFinalPrice] = useState(0);

    const buyProduct = () => {
        if (productId + 13 == id) {
            const object = {
                id: appleApi[0].iphone[productId].id,
                name: apple[0].iphone[productId].name_text,
                price: newPrice,
                color: isGrayIphone,
                image1: appleApi[0].iphone[productId].iphone_color1,
                image2: appleApi[0].iphone[productId].iphone_color2,
                memory: isHoverMemoryIphone,
                storage: isHoverStorageIphone
            }

            userArray.map(item => {
                if (loginArray[0].login == item.email) {
                    item.array.push(object)
                }
            })

        }

        localStorage.setItem('userArray', JSON.stringify(userArray))
        localStorage.setItem('loginArray', JSON.stringify(loginArray))
        console.log(userArray);
    }






    const onChangeValueIphone = (event) => {
        if (event.target.value == "gray") {
            setIsGrayIphone(true)
            console.log(newPrice);
        } else {
            setIsGrayIphone(false)
        }
    }

    const onClickMemoryIphone = () => {
        if (isHoverMemoryIphone == true) {
            setIsHoverMemoryIphone(false)
            setNewPrice(newPrice + 25000)
        } else {
            setIsHoverMemoryIphone(true)
            setNewPrice(newPrice - 25000)
        }
    }

    const onClickStorageIphone = () => {
        if (isHoverStorageIphone == true) {
            setIsHoverStorageIphone(false)
            setNewPrice(newPrice + 25000)
        } else {
            setIsHoverStorageIphone(true)
            setNewPrice(newPrice - 25000)
        }
    }

    return (
        <>
            {appleApi.length !== 0
                ?
                appleApi[0].iphone.map(item => {
                    console.log(item.id === +id)
                    if (item.id === +id) {
                        return (
                            <div>
                                <div className="iphonepage_block">
                                    <div
                                        className="iphone_background"
                                        style={{
                                            backgroundPositionX: "center",
                                            // backgroundPositionY: "50px",
                                            backgroundRepeat: "no-repeat",
                                            backgroundSize: "cover",
                                            backgroundImage: `url(${item.backgroundImage})`,
                                            textAlign: "center",
                                        }}>
                                        <img style={{ margin: "80px auto", opacity: `${item.opacity}` }} src={item.name} />
                                    </div>
                                    <div className="iphonepage_descriptions" style={{ background: `${item.backgoundColor}`, color: `${item.fontColor}` }}>
                                        <div className="information_block">
                                            <h1 className="product_mainText">{item.mainText}</h1>
                                            <h3 className="product_description">{item.description}</h3>
                                            <p style={{ color: "#767676", fontSize: 20, fontWeight: 600 }}>От {item.price} ₸</p>
                                        </div>
                                        <div className="product_info">
                                            <div className="iphoneInfo_block">
                                                <div className="product_item_iphone">
                                                    <div className="item_info">
                                                        <h3>{item.information.display}</h3>
                                                        <p>Дисплей</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.chip_img} />
                                                        <p>{item.information.chip}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.back_cameras_img} />
                                                        <p>{item.information.back_cameras}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.battery_img} />
                                                        <p>{item.information.battery}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.cellular_img} />
                                                        <p>{item.information.cellular}</p>
                                                    </div>
                                                    <div>
                                                        <img className="info_image" src={item.information.faceId_img} />
                                                        <p>{item.information.faceId}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="buy_product_block">
                                            <div className="product_appearance">
                                                <div className="product_appearance_img">
                                                    <img className="for_mobile_productImg" src={item.iphone_color1} style={{ display: isGrayIphone ? 'block' : 'none' }} />
                                                    <img className="for_mobile_productImg" src={item.iphone_color2} style={{ display: isGrayIphone ? 'none' : 'block' }} />
                                                </div>
                                                <div className="for_price_block">
                                                    <h1>{newPrice} ₸</h1>
                                                </div>
                                            </div>
                                            <div className="product_dates">
                                                <div className="chip_block">
                                                    <img src={item.information.chip_img} />
                                                </div>
                                                <div className="product_color" onChange={onChangeValueIphone}>
                                                    <h3>Цвет:</h3>
                                                    <label>
                                                        <img style={{ width: 30 }} src={item.color1} />
                                                        <input style={{ opacity: 0 }} type="radio" name="color" value={item.input_value1} />
                                                    </label>
                                                    <label>
                                                        <img style={{ width: 30 }} src={item.color2} />
                                                        <input style={{ opacity: 0 }} type="radio" name="color" value={item.input_value2} />
                                                    </label>
                                                </div>
                                                <div className="memory_date_block">
                                                    <h3>Память:</h3>
                                                    <p className="qwestion_for_date">Сколько память вам подходит?</p>
                                                    <label>
                                                        <div className="memory_card" onClick={onClickMemoryIphone} style={{ border: isHoverMemoryIphone ? "2px solid #0071e3" : "1px solid #86868b" }}>
                                                            <h3>256 ГБ единой памяти</h3>
                                                            <p style={{ opacity: isHoverMemoryIphone ? 0 : 1 }} >- 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="memory" />
                                                    </label>
                                                    <label>
                                                        <div className="memory_card" onClick={onClickMemoryIphone} style={{ border: isHoverMemoryIphone ? "1px solid #86868b" : "2px solid #0071e3" }}>
                                                            <h3>512 ТБ единой памяти</h3>
                                                            <p style={{ opacity: isHoverMemoryIphone ? 1 : 0 }} >+ 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="memory" />
                                                    </label>
                                                </div>
                                                <div className="storage_date_block">
                                                    <h3>Связь:</h3>
                                                    <label>
                                                        <div className="storage_card" onClick={onClickStorageIphone} style={{ border: isHoverStorageIphone ? "2px solid #0071e3" : "1px solid #86868b" }}>
                                                            <h3>Wi-Fi</h3>
                                                            <p style={{ opacity: isHoverStorageIphone ? 0 : 1 }} >- 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="storage" />
                                                    </label>
                                                    <label>
                                                        <div className="storage_card" onClick={onClickStorageIphone} style={{ border: isHoverStorageIphone ? "1px solid #86868b" : "2px solid #0071e3" }}>
                                                            <h3>Wi-Fi + Сотовый</h3>
                                                            <p style={{ opacity: isHoverStorageIphone ? 1 : 0 }} >+ 25 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="storage" />
                                                    </label>
                                                </div>
                                                <Link to={'/basket/products'}>
                                                    <Button onClick={buyProduct}>Купить</Button>
                                                </Link>
                                            </div>
                                        </div>

                                        <div className="ios15_block">
                                            <div className="ios15_text">
                                                <h2>iOS 15</h2>
                                                <p style={{ fontSize: 20 }}>На связи. В данный момент.</p>
                                            </div>
                                        </div>
                                        <div className="ios16_block">
                                            <div className="ios16_text">
                                                <h2>iOS 16</h2>
                                                <p style={{ fontSize: 20 }}>Личность - это мощно.</p>
                                            </div>
                                            <div className="ios16_background">
                                                <img className="ios16_img" src="../AccessoriesForPages/ios16.jpg" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="pro_block">
                                        <img className="fixedImg" src="../iPhone/pro/water_resistant.jpg" />
                                    </div>
                                    <div className="iphone13_background_block">
                                        <h3 style={{ fontSize: 35 }}>Диагональ</h3>
                                    </div>
                                </div>
                            </div>
                        )
                    }
                })
                :
                null
            }

        </>
    )
}