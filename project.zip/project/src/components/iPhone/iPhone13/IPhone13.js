import React, { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { Price } from "../../Mac/card/price/Price"
import { Button } from "../../UI/button/Button"
import "./IPhone13.css"
import { getProducts } from "../../../API/productsAPI"


export const IPhone13 = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    console.log(appleApi);

    return (
        <div>
            <Link to={"/iphone/14"}>
                <div className="iPhone13_block">
                    <div className="iPhone13_text">
                        <img src="../iPhone/iphone_13_logo.jpg" />
                        <h2 className="main_paragraf">Ваша новая супер сила.</h2>
                        <Price>{appleApi.length !== 0
                            ?
                            appleApi[0].iphone[1].price
                            :
                            null}</Price>
                        <Button>Купить</Button>
                    </div>
                    <div className="iPhone13_background">
                        <img className="iPhone13_img" src="../iPhone/iphone_13.png" />
                    </div>

                </div>
            </Link>
        </div>

    )
}