import React, { useEffect, useState } from "react"
import { Price } from "../Mac/card/price/Price"
import { Button } from "../UI/button/Button"
import "./Watch.css"
import { Benefits } from "../Benefits/Benefits";
import { Appearance } from "../Mac/card/images/appearance";
import { Card } from "../Mac/card/Card";
import { Link } from "react-router-dom";
import { getProducts } from "../../API/productsAPI";


export const Watch = () => {

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);


    return (
        <div>
            <div className="watch_block">
                <Link to={"/watch/17"}>
                    <div className="watch_text">
                        <img src="../Watch/logo_watch_s7.png" />
                        <h1 className="main_paragraf">Впереди полноэкранный режим.</h1>
                        <Price>{appleApi.length !== 0
                            ?
                            appleApi[0].watch[0].price
                            :
                            null}</Price>
                        <Button>Купить</Button>
                    </div>
                    <div className="watch_background">
                        <img className="watch_img" src="../Watch/hero_s7.jpg" />
                    </div>
                </Link>
            </div>
            <div>
                <Link to={"/watch/18"}>
                    <div className="watch_container">
                        <div className="watch_text_block">
                            <img src="../Watch/logo-watch-se.png" />
                            <h1 className="main_paragraf">Тяжелые функции. <br /> Свет на цену.</h1>
                            <div style={{ color: "white" }}>
                                <Price>{appleApi.length !== 0
                                    ?
                                    appleApi[0].watch[1].price
                                    :
                                    null}</Price>
                            </div>
                            <Button>Купить</Button>
                        </div>
                        <div className="watch_image_block">
                            <img className="watch_img" src="https://www.apple.com/v/watch/ax/images/overview/se/tile-watch-se__knji2d25x8qe_large.jpg" />
                        </div>
                    </div>
                </Link>
            </div>
            <div className="watch_items">
                <div className="watch_description">
                    <h1 className="main_paragraf">Какие Apple Watch подходят именно вам?</h1>
                </div>
                <div className="products_watch">
                    {appleApi.length !== 0
                        ?
                        appleApi[0].watch.map(item => {
                            return (
                                <div className="for_mobile">
                                    <Card>
                                        <Link to={"/watch/" + `${item.id}`}>
                                            <div style={{ marginBottom: 20 }}>
                                                <Appearance>{item.image}</Appearance>
                                            </div>
                                            {item.name}
                                            <Price>{item.price}</Price>
                                            <Button>Купить</Button>
                                        </Link>
                                    </Card>
                                </div>

                            )
                        })
                        :
                        null}


                </div>
            </div>
            <Benefits />
            <div className="ios_watch_block">
                <div className="ios_text">
                    <h2>watchOS 9</h2>
                    <p style={{ fontSize: 20, fontWeight: 600 }}>Чрезвычайно проницательный.<br /> Исключительно личный.</p>
                </div>
                <div className="ios_background">
                    <img className="ios_img" src="../Watch/watchos_full.jpg" />
                </div>
            </div>
        </div>
    )
}