import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import "./WatchProducts.css"
import { apple } from "../../apple"
import { Link } from "react-router-dom";
import { Button } from "../../UI/button/Button";
import { getProducts } from "../../../API/productsAPI";


export const WatchProducts = ({ userArray, loginArray }) => {
    let { id } = useParams();

    let productId = id - 17;

    const [appleApi, setApple] = useState([]);

    useEffect(() => {
        async function fetchData() {
            return await getProducts();
        }
        fetchData().then((res) => setApple(res));
    }, []);

    const [newPrice, setNewPrice] = useState(apple[0].watch[productId].price)

    const [isGrayWatch, setIsGrayWatch] = useState(true)
    const [isHoverMemoryWatch, setIsHoverMemoryWatch] = useState(true)


    const buyProduct = () => {
        if (productId + 17 == id) {
            const object = {
                id: appleApi[0].watch[productId].id,
                name: appleApi[0].watch[productId].name,
                price: newPrice,
                color: isGrayWatch,
                image1: appleApi[0].watch[productId].watch_color1,
                image2: appleApi[0].watch[productId].watch_color2,
                memory: isHoverMemoryWatch,
            }

            userArray.map(item => {
                if (loginArray[0].login == item.email) {
                    item.array.push(object)
                }
            })

        }

        localStorage.setItem('userArray', JSON.stringify(userArray))
        localStorage.setItem('loginArray', JSON.stringify(loginArray))
        console.log(userArray);
    }






    const onChangeValueWatch = (event) => {
        if (event.target.value == "gray") {
            setIsGrayWatch(true)
            console.log(newPrice);
        } else {
            setIsGrayWatch(false)
        }
    }

    const onClickMemoryWatch = () => {
        if (isHoverMemoryWatch == true) {
            setIsHoverMemoryWatch(false)
            setNewPrice(newPrice + 5000)
        } else {
            setIsHoverMemoryWatch(true)
            setNewPrice(newPrice - 5000)
        }
    }



    return (
        <>
            {appleApi.length !== 0
                ?
                appleApi[0].watch.map(item => {
                    console.log(item.id === +id)
                    if (item.id === +id) {
                        return (
                            <div>
                                <div className="watchpage_block">
                                    <div
                                        className="watch_background"
                                        style={{
                                            height: 750,
                                            backgroundPositionX: "center",
                                            // backgroundPositionY: "50px",
                                            backgroundRepeat: "no-repeat",
                                            backgroundSize: "cover",
                                            backgroundImage: `url(${item.backgroundImage})`,
                                            textAlign: "center",
                                        }}>
                                        {/* <h2 style={{paddingTop: 75}}>{item.name}</h2> */}
                                        <img style={{ paddingTop: 75 }} src={item.name_img} />
                                    </div>
                                    <div className="watchpage_descriptions" style={{ background: `${item.backgoundColor}`, color: `${item.fontColor}` }}>
                                        <div className="information_block">
                                            <h1 className="product_mainText">{item.mainText}</h1>
                                            <h3 className="product_description">{item.description}</h3>
                                            <p style={{ color: "#767676", fontSize: 20, fontWeight: 600 }}>От {item.price} ₸</p>
                                        </div>
                                        <div className="product_info">
                                            <div className="watchInfo_block">
                                                <div className="product_item_watch">
                                                    <div className="item_info">
                                                        <h3>{item.information.size}</h3>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.display_img} />
                                                        <p>{item.information.display}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.blood_oxygen_img} />
                                                        <p>{item.information.blood_oxygen_app}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.ecg_img} />
                                                        <p>{item.information.ecg_app}</p>
                                                    </div>
                                                    <div className="item_info">
                                                        <img className="info_image" src={item.information.heart_img} />
                                                        <p>{item.information.heart_app}</p>
                                                    </div>
                                                    <div>
                                                        <img className="info_image" src={item.information.sos_img} />
                                                        <p>{item.information.sos_app}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="comparison_block">
                                            <div className="series_block">
                                                <img src="../Watch/products/display_s7.jpg" />
                                                <img style={{ marginTop: 75 }} src="../Watch/display_s7_logo.png" />
                                            </div>
                                            <div className="series_block">
                                                <img src="../Watch/products/display_s3.jpg" />
                                                <img style={{ marginTop: 75 }} src="../Watch/display_s3_logo.png" />
                                            </div>
                                        </div>

                                        <div className="buy_product_block">
                                            <div className="product_appearance">
                                                <div className="product_appearance_img">
                                                    <img className="for_mobile_productImg" src={item.watch_color1} style={{ display: isGrayWatch ? 'block' : 'none', width: 300 }} />
                                                    <img className="for_mobile_productImg" src={item.watch_color2} style={{ display: isGrayWatch ? 'none' : 'block', width: 300 }} />
                                                </div>
                                                <div className="for_price_block">
                                                    <h1>{newPrice} ₸</h1>
                                                </div>
                                            </div>
                                            <div className="product_dates">
                                                <div className="chip_block">
                                                    <img src={item.information.chip_img} />
                                                </div>
                                                <div className="product_color" onChange={onChangeValueWatch}>
                                                    <h3>Цвет:</h3>
                                                    <label>
                                                        <img style={{ width: 30 }} src={item.color1} />
                                                        <input style={{ opacity: 0 }} type="radio" name="color" value={item.input_value1} />
                                                    </label>
                                                    <label>
                                                        <img style={{ width: 30 }} src={item.color2} />
                                                        <input style={{ opacity: 0 }} type="radio" name="color" value={item.input_value2} />
                                                    </label>
                                                </div>
                                                <div className="memory_date_block">
                                                    <h3>Размер корпуса:</h3>
                                                    <label>
                                                        <div className="memory_card" onClick={onClickMemoryWatch} style={{ border: isHoverMemoryWatch ? "2px solid #0071e3" : "1px solid #86868b" }}>
                                                            <h3>41mm</h3>
                                                            <p style={{ opacity: isHoverMemoryWatch ? 0 : 1 }} >- 5 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="memory" />
                                                    </label>
                                                    <label>
                                                        <div className="memory_card" onClick={onClickMemoryWatch} style={{ border: isHoverMemoryWatch ? "1px solid #86868b" : "2px solid #0071e3" }}>
                                                            <h3>45mm</h3>
                                                            <p style={{ opacity: isHoverMemoryWatch ? 1 : 0 }} >+ 5 000 ₸</p>
                                                        </div>
                                                        <input style={{ opacity: 0 }} type="radio" name="memory" />
                                                    </label>
                                                </div>
                                                <Link to={'/basket/products'}>
                                                    <Button onClick={buyProduct}>Купить</Button>
                                                </Link>

                                            </div>
                                        </div>

                                        <div className="peculiarities_block">
                                            <h2>Легко на глазах. Легко на пальцах.</h2>
                                            <div className="peculiarities_container">
                                                <div className="series_block">
                                                    <img src="../Watch/display_01.jpg" />
                                                    <p style={{ padding: "0 100px" }}>По всей системе кнопки были переработаны, чтобы использовать преимущества большего дисплея.</p>
                                                </div>
                                                <div className="series_block">
                                                    <img src="../Watch/display_02.jpg" />
                                                    <p style={{ padding: "0 100px" }}>Сначала Apple Watch - клавиатура QWERTY позволяет нажимать или перемещать от буквы к букве с помощью QuickPath.</p>
                                                </div>
                                                <div className="series_block">
                                                    <img src="../Watch/display_03.jpg" />
                                                    <p style={{ padding: "0 100px" }}>Используйте Scribble для написания писем на экране и составление текста или электронного письма.</p>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="ios_watch_block">
                                            <div className="ios_text">
                                                <h2>watchOS 9</h2>
                                                <p style={{ fontSize: 20, fontWeight: 600 }}>Чрезвычайно проницательный.<br /> Исключительно личный.</p>
                                            </div>
                                            <div className="ios_background">
                                                <img className="ios_img" src="../Watch/watchos_full.jpg" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )
                    }
                })
                :
                null
            }

        </>
    )
}